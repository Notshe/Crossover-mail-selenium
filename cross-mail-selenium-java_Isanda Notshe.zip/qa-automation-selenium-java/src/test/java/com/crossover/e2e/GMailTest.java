package com.crossover.e2e;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import junit.framework.TestCase;
import org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.crossover.e2e.Pages.Login;
import com.crossover.e2e.Pages.SendEmail;
import com.sun.javafx.tk.Toolkit;

public class GMailTest extends TestCase {
	
	public WebDriverWait wait;
	WebDriver driver = new FirefoxDriver();
	Properties properties = new Properties();
	
	
	@BeforeTest
	public void setUp() throws Exception {
		
		wait = new WebDriverWait(driver, 15);
		driver.manage().window().maximize();
		driver.get("https://mail.google.com/");
		properties.load(new FileReader(new File("test.properties")));
	}
	
	@Test
	public void testSendEmail()throws Exception, AWTException, InterruptedException {
		
		//Email address entered and next button clicked on
	    Login logIntoEmail = new Login(driver);
	    SendEmail sendEmail = new SendEmail(driver);
	    logIntoEmail.typeEmailAddress(properties.getProperty("username"));
	    logIntoEmail.clickOnNextButton();
	  	Thread.sleep(8000);
	  	//Enter the password and click next
		logIntoEmail.typePassword(properties.getProperty("password"));
		logIntoEmail.clickOnNextPasswordButton();
		//wait for email address page to appear and compose new email
		Thread.sleep(8000);
		sendEmail.clickOnComposeButton();
		Thread.sleep(2000);
		//Once compose email is open, enter to address, subject, etc
		sendEmail.inputToField(properties.getProperty("username"));
		sendEmail.inputSubjectField("RandomUniqueText");
		sendEmail.inputBodyfield("RandomText again");
		Thread.sleep(2000);
		
		
		//upload file. Try use robot class to do this (look into this when I have more time) - Wasn't working and was consuming too much time. 
		//specify file location with extension
		//StringSelection sel = new StringSelection("C:\\Team\\Work stuff cvs an all\\Certificate Scan.pdf");
		//Copy 
		//java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sel, null);
		//System.out.println("Selection" + sel);
		//create object of robot class
		//Robot robot = new Robot();
		//Thread.sleep(4000);
		
		//Click the send button
		sendEmail.clickSendButton();
		Thread.sleep(9000);
		Thread.sleep(3000);
		//Open the email you just sent
		sendEmail.openCorrectEmail();
		Thread.sleep(5000);
		//Assertions - Hard assert stops program if assert fails
		sendEmail.verifyBody("RandomText again");
		System.out.println("Body verified");
		sendEmail.verifySubject("RandomUniqueText");
		System.out.println("Subject Verified");
		
	}
	
	
	
	
}
