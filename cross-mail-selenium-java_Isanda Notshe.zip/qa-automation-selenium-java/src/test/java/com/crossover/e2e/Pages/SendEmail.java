package com.crossover.e2e.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.asserts.Assertion;

import junit.framework.Assert;

public class SendEmail {
	WebDriver driver;
	By composeButton = By.xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[1]/div[1]/div[2]/div/div/div/div[1]/div/div");
	By toField = By.name("to");
	By subjectField = By.xpath("//*[@id=\":pi\"]");
	By bodyField = By.xpath("//*[@id=\":qn\"]");
	By sendButton = By.xpath("//*[@id=\":p8\"]");
	By emailThreads = By.xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div/div[6]/div/div[1]/div[2]/div/table/tbody/tr[1]/td[6]/div/div/div/span/span");
	
	public SendEmail(WebDriver driver)
	{
		this.driver = driver;
	}

	public void clickOnComposeButton()
	{
		driver.findElement(composeButton).click();
	}
	
	public void inputToField(String toInput)
	{
		driver.findElement(toField).clear();
		driver.findElement(toField).sendKeys(toInput);
	}
	
	public void inputSubjectField(String subjectInput)
	{
		driver.findElement(subjectField).clear();
		driver.findElement(subjectField).sendKeys(subjectInput);
	}
	
	public void inputBodyfield(String bodyInput)
	{
		driver.findElement(bodyField).clear();
		driver.findElement(bodyField).sendKeys(bodyInput);
	}
	
	public void clickSendButton()
	{
		driver.findElement(sendButton).click();
	}
	
	public void openCorrectEmail()
	{
		driver.findElement(emailThreads).click();
	}
	
	
	public void verifyBody(String expectedText)
	{
		String verifyEmailBody = driver.findElement(By.xpath("//*[@id=\":ph\"]")).getText();
		org.testng.Assert.assertEquals(verifyEmailBody, expectedText);
	}
	
	public void verifySubject(String expectedSubjectText)
	{
		String verifyEmailSubject = driver.findElement(By.xpath("//*[@id=\":sk\"]")).getText();
		org.testng.Assert.assertEquals(verifyEmailSubject, expectedSubjectText);
	}
	
//	public void openCorrectEmail(String emailSubject)
//	{
//		for(int i = 0; i <emailThreads.size(); i++)
//		{		
//			if(emailThreads.get(i).getText().contains(emailSubject)) {
//				emailThreads.get(i).click();
//				break;
//			}
//		}
//	}
	
}
