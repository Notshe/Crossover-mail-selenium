package com.crossover.e2e.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login {
	
	WebDriver driver;
	By emailAddress = By.id("identifierId");
	By passWord = By.name("password");
	By loginButton = By.id("identifierNext");
	By loginButtonPassword = By.id("passwordNext");
	
	
	public Login(WebDriver driver)
	{
		this.driver = driver;
		
	}
	
	public void typeEmailAddress(String inputEmail)
	{
		driver.findElement(emailAddress).sendKeys(inputEmail);
	}
	
	public void typePassword(String pass)
	{
		driver.findElement(passWord).sendKeys(pass);
	}
	
	public void clickOnNextButton()
	{
		driver.findElement(loginButton).click();
	}
	
	public void clickOnNextPasswordButton()
	{
		driver.findElement(loginButtonPassword).click();
	}
	
}
